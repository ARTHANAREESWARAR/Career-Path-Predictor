<?php
// Initialize the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    .box{
        
        width: 5000px;
        height: 20000px;
        align-items: center;
        color: white;
        background-color: orangered;
        padding: 20px;
        border-radius: 10px;
    }
</style>
<body>
    <h1>This page is under Development</h1>
    <a class="box" href="main.php">HOME</a>
</body>
</html>